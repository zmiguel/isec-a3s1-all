#include <stdio.h>
#include <string.h>
#include <iostream>
#include <sstream>

int main (){
    printf("fuck off!\n");
}
